//
//  ViewController.swift
//  drawingDemo
//
//  Created by Bhavik Vachhani on 8/31/17.
//  Copyright © 2017 Bhavik Vachhani. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var abc: SignatureView!
    override func viewDidLoad() {
        super.viewDidLoad()
        abc.lineWidth = 20
        // Do any additional setup after loading the view, typically from a nib.
    }


    
    @IBAction func Redcolor(_ sender: Any) {
        abc.isEraserSelected = false
        abc.lineColor = UIColor.red.cgColor
    }
    @IBAction func BlackColor(_ sender: Any) {
        abc.isEraserSelected = false
        abc.lineColor = UIColor.black.cgColor
    }

    @IBAction func btnClear(_ sender: Any) {
        abc.clearSignature()
    }

    @IBAction func btnEraser(_ sender: Any) {
        abc.isEraserSelected = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

